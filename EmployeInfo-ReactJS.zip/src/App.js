import React, { Fragment } from "react";
import styles from "./styles.css";
//import Navbar from "react-bootstrap/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import { render } from "react-dom";
import Employeinfo from "./components/Employeinfo";

let App = () => {
  return (
    <Fragment>
      <nav className="navbar bg-dark navbar-expand-sm navbar-brand">
        <a href="/" className="text-decoration-none text-success">
          hi iam achyu
        </a>
      </nav>
      <Employeinfo />
    </Fragment>
  );
};

export default App;
