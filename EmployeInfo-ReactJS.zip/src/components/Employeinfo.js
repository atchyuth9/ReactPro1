import React from "react";

class Employeinfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      Emp: {
        CompanyName: "Virtusa",
        Image: "IMG_20200406_150615_680.jpg",
        EmpName: "achyuth Brundavanam",
        Role: "Associate Engineer Technology",
        Location: "Hyderabad",
        Sal: 700000,
        Skills: ["mqsql", "java", "springboot"]
      }
    };
  }
  render() {
    let {
      CompanyName,
      Image,
      EmpName,
      Role,
      Location,
      Sal,
      Skills
    } = this.state.Emp;
    return (
      <div className="container mt-3">
        <div className="row">
          <div className="col-md-3">
            <div className="card">
              <img src={Image} alt="turn on the data" />
              <div className="card-body">
                <span> Company Name: {CompanyName} </span> <br />
                <span>Employe Name: {EmpName}</span>
                <br />
                <span>Employe Role: {Role}</span>
                <br />
                <span>Employe Location: {Location}</span>
                <br />
                <span>Salary: {Sal}</span>
                <br />
                <p>Tech Skills:</p>
                <ul>
                  <li>{Skills[0]}</li>
                  <li>{Skills[1]}</li>
                  <li>{Skills[2]}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Employeinfo;
